**********************************README***********************************
1. This directory contains 14 folders.Each file contains the consensus results
   of different datasets under s = 1~7.
2. The followings are descriptions of the .txt files inside the folders:
   Each type 1 network is seperated by '+', '*', '-' and '--'.
        Genes before '+' are weight 3 genes (core network genes).
        Genes between '+' and '*' are weight 2 genes.
        Genes between '*' and '-' are linker genes.
        Genes between '-' and '--' are weight 1 genes which are selected by HotNet2 consensus method.
   The type 2 networks are followed with the type 1 networks, separared with a blank line.
   Genes with a parentheses also belong to type 1 networks with the network index of the number in the parentheses.
3. For example, pancancer_A/subnet_1.txt stores the consensus results of pan-cancer dataset A when s = 1.
